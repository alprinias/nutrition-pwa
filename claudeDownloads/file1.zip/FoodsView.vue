<template>
  <div class="p-4 space-y-3">
    <div class="card">
      <h2 class="font-semibold text-gray-800 mb-1">Ingredients & recipes</h2>
      <p class="text-sm text-gray-400">Searchable ingredient and recipe database — coming in Phase 4.</p>
    </div>
  </div>
</template>
