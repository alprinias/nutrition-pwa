<template>
  <div class="p-4 space-y-3">
    <div class="card">
      <h2 class="font-semibold text-gray-800 mb-1">Add meal</h2>
      <p class="text-sm text-gray-400">Search ingredients and recipes — coming in Phase 4.</p>
    </div>
  </div>
</template>
