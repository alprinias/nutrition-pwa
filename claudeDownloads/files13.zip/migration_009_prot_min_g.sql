-- migration_009_prot_min_g.sql
-- Adds explicit minimum protein grams target to user_targets
alter table public.user_targets
  add column if not exists prot_min_g numeric default 120;
