-- ============================================================
-- migration_008_visibility.sql
-- Public/private ingredients & recipes + moderation queue
-- ============================================================

-- 1. Add visibility columns to ingredients and recipes
alter table public.ingredients
  add column if not exists owner_user_id uuid references auth.users(id),
  add column if not exists is_public     boolean not null default true;

alter table public.recipes
  add column if not exists owner_user_id uuid references auth.users(id),
  add column if not exists is_public     boolean not null default true;

-- 2. Set admin as owner of all existing rows
update public.ingredients
set owner_user_id = (select value::uuid from public.app_config where key = 'admin_user_id')
where owner_user_id is null;

update public.recipes
set owner_user_id = (select value::uuid from public.app_config where key = 'admin_user_id')
where owner_user_id is null;

-- 3. Add show_public_foods preference to user_targets
alter table public.user_targets
  add column if not exists show_public_foods boolean not null default true;

-- 4. Moderation requests table
create table if not exists public.moderation_requests (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  entity_type  text not null check (entity_type in ('ingredient', 'recipe')),
  entity_id    integer not null,
  status       text not null default 'pending'
                 check (status in ('pending', 'approved', 'rejected')),
  note         text,
  admin_note   text,
  created_at   timestamptz default now(),
  reviewed_at  timestamptz,
  reviewed_by  uuid references auth.users(id),
  unique (entity_type, entity_id, status)  -- one pending request per item
);

alter table public.moderation_requests enable row level security;

-- Users can see their own requests; admin sees all
create policy "mod_requests_select" on public.moderation_requests
  for select using (
    user_id = auth.uid()
    or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id')
  );

-- Users can insert their own requests
create policy "mod_requests_insert" on public.moderation_requests
  for insert with check (user_id = auth.uid());

-- Only admin can update (approve/reject)
create policy "mod_requests_update" on public.moderation_requests
  for update using (
    auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id')
  );

-- 5. Drop old blanket write policies on ingredients / recipes / recipe_items
drop policy if exists "ingredients_write_authenticated"  on public.ingredients;
drop policy if exists "recipes_write_authenticated"      on public.recipes;
drop policy if exists "recipe_items_write_authenticated" on public.recipe_items;

-- 6. New RLS policies for ingredients
-- SELECT: public items OR your own private items
create policy "ingredients_select" on public.ingredients
  for select using (
    is_public = true
    or owner_user_id = auth.uid()
  );

-- INSERT: authenticated users, must set own owner_user_id, must be private
create policy "ingredients_insert" on public.ingredients
  for insert with check (
    auth.role() = 'authenticated'
    and owner_user_id = auth.uid()
    and is_public = false
  );

-- UPDATE: owner of private items OR admin (admin can edit public too)
create policy "ingredients_update" on public.ingredients
  for update using (
    (owner_user_id = auth.uid() and is_public = false)
    or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id')
  );

-- DELETE: owner of private items OR admin
create policy "ingredients_delete" on public.ingredients
  for delete using (
    (owner_user_id = auth.uid() and is_public = false)
    or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id')
  );

-- 7. New RLS policies for recipes
create policy "recipes_select" on public.recipes
  for select using (
    is_public = true
    or owner_user_id = auth.uid()
  );

create policy "recipes_insert" on public.recipes
  for insert with check (
    auth.role() = 'authenticated'
    and owner_user_id = auth.uid()
    and is_public = false
  );

create policy "recipes_update" on public.recipes
  for update using (
    (owner_user_id = auth.uid() and is_public = false)
    or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id')
  );

create policy "recipes_delete" on public.recipes
  for delete using (
    (owner_user_id = auth.uid() and is_public = false)
    or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id')
  );

-- 8. recipe_items: follow parent recipe visibility
create policy "recipe_items_select" on public.recipe_items
  for select using (
    exists (
      select 1 from public.recipes r
      where r.id = recipe_id
      and (r.is_public = true or r.owner_user_id = auth.uid())
    )
  );

create policy "recipe_items_insert" on public.recipe_items
  for insert with check (
    exists (
      select 1 from public.recipes r
      where r.id = recipe_id
      and (r.owner_user_id = auth.uid()
           or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id'))
    )
  );

create policy "recipe_items_update" on public.recipe_items
  for update using (
    exists (
      select 1 from public.recipes r
      where r.id = recipe_id
      and (r.owner_user_id = auth.uid()
           or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id'))
    )
  );

create policy "recipe_items_delete" on public.recipe_items
  for delete using (
    exists (
      select 1 from public.recipes r
      where r.id = recipe_id
      and (r.owner_user_id = auth.uid()
           or auth.uid() = (select value::uuid from public.app_config where key = 'admin_user_id'))
    )
  );
