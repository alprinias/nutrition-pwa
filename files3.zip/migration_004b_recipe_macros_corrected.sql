-- ============================================================
-- migration_004b_recipe_macros_corrected.sql
-- Stores per-unit macro rates on recipes:
--   unit='gr'  → macros per 1 gram  (user logs grams consumed)
--   unit='pc'  → macros per 1 piece (user logs pieces consumed)
-- Also stores total batch macros for display.
-- ============================================================

-- Add columns if not already there
alter table public.recipes
  add column if not exists calories_per_unit  numeric default 0,
  add column if not exists protein_per_unit   numeric default 0,
  add column if not exists carbs_per_unit     numeric default 0,
  add column if not exists fat_per_unit       numeric default 0,
  add column if not exists calories_total     numeric default 0,
  add column if not exists protein_total      numeric default 0,
  add column if not exists carbs_total        numeric default 0,
  add column if not exists fat_total          numeric default 0;

-- Drop old per-serving columns if they exist
alter table public.recipes
  drop column if exists calories_per_serving,
  drop column if exists protein_per_serving,
  drop column if exists carbs_per_serving,
  drop column if exists fat_per_serving;

-- Compute total batch macros from recipe_items × ingredients
-- then derive per-unit rate from total_weight_g (for gr) or servings (for pc)
update public.recipes r
set
  calories_total  = totals.cal,
  protein_total   = totals.prot,
  carbs_total     = totals.carb,
  fat_total       = totals.fat,
  -- per-unit rate: divide by weight(gr) or pieces(pc)
  calories_per_unit = case
    when r.unit = 'pc' then totals.cal  / greatest(r.servings, 1)
    else                    totals.cal  / greatest(r.total_weight_g, 1)
  end,
  protein_per_unit = case
    when r.unit = 'pc' then totals.prot / greatest(r.servings, 1)
    else                    totals.prot / greatest(r.total_weight_g, 1)
  end,
  carbs_per_unit = case
    when r.unit = 'pc' then totals.carb / greatest(r.servings, 1)
    else                    totals.carb / greatest(r.total_weight_g, 1)
  end,
  fat_per_unit = case
    when r.unit = 'pc' then totals.fat  / greatest(r.servings, 1)
    else                    totals.fat  / greatest(r.total_weight_g, 1)
  end
from (
  select
    ri.recipe_id,
    sum(i.calories  * ri.quantity / greatest(i.ref_quantity, 1)) as cal,
    sum(i.protein_g * ri.quantity / greatest(i.ref_quantity, 1)) as prot,
    sum(i.carbs_g   * ri.quantity / greatest(i.ref_quantity, 1)) as carb,
    sum(i.fat_g     * ri.quantity / greatest(i.ref_quantity, 1)) as fat
  from public.recipe_items ri
  join public.ingredients i on i.id = ri.ingredient_id
  group by ri.recipe_id
) totals
where totals.recipe_id = r.id;
